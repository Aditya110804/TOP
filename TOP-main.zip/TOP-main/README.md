# TOP
Transport Optimization Program
(TOP) main purpose is to optimize the transportation system. Optimization includes the method to use resources 
efficiently like transportation system so that it saves time and even makes it 
available on time for passengers and also to reduce pollution, and conserve 
energy. Sharing of the vehicle is Vehicle pooling so that multiple numbers of 
people can travel in a single-vehicle. the use of vehicle pooling reduces single 
individuals Travelling costs, reduces the fuel cost, and reduces the number of 
vehicles. Due to the growth in the population, there is inadequate 
transportation through their vehicle. Rather than using a different mode of 
Transportation. It results in an increasing amount of traffic on roads also 
increases pollution and increases the time to travel to their destination. So, by 
Smart transportation using a vehicle pooling system the individual can travel 
and share their rides with different people of the same destination. In this 
paper, we have carried out a survey. Reviewing various Literature papers on 
carpooling it aims to reduce the number of vehicles by sharing the rides. 
Electric taxis have the potential to improve urban air quality and save drivers’ 
energy expenditure. Consequently, the running cost of EVs comes to Rs 1 per 
km, Rs 9 for petrol, Rs 6 for diesel, and about Rs 2.5 per km for vehicles being 
run on CNG. Although 3 battery electric vehicles (BEVs) have drawbacks 
such as the limited range and charging inconvenience, 4 technological 
Page 5 of 29
progresses has been presenting the promising potential for electric taxis Its 
website and mobile apps connect drivers and passengers willing to travel 
together between cities and share the cost of the journey[1]. The company does 
not own any vehicles; it is a broker and receives a commission (between 18% 
and 21%) from every booking. In this era of technology, everything is getting 
combined with technology to perform or transform for the better so we will be 
using technology to make an effort to solve this problem.[2] We will be 
building a website that will be a platform that will connect the passengers with 
the traveling mode.
